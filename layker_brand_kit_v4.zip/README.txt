Layker Brand Kit (v4)
=====================
Contents:
  - layker_icon_[light|dark]_eye-[front|left].svg   : Fish + three chevrons icon (two eye placements)
  - layker_wordmark_[light|dark].svg                : "Layker" wordmark
  - layker_wordmark_[light|dark]_tagline.svg        : Wordmark + tagline
  - layker_lockup_horizontal_[light|dark]_eye-[...].svg : Icon + wordmark horizontal lockup
  - palette.json                                    : Color palette

Notes:
  - Eye placement "front" is closer to the nose; "left" sits slightly back (per your guidance).
  - Three chevrons, no bottom triangle; chevrons use secondary/accent/dark tones.
  - SVGs are vector and scale cleanly. For PNGs, export at sizes you need (e.g., 512, 1024).
  - Wordmark uses common system fonts in the SVG; for brand consistency, consider swapping to your preferred font.
