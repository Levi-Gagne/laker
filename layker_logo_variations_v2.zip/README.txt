Layker Logo Variations (v2)

- A: Fish outline + two chevrons (eye left).
- B: Solid fish with negative-space chevrons (eye left).
- C: Circular badge with same fish (eye left).
- D: Minimal fish mark (eye left).

Palette (see palette.json):
{
  "deep_lake_blue": "#1862A4",
  "aqua_teal": "#16A5A3",
  "mist": "#E8F1F8",
  "charcoal": "#1F2937",
  "coral": "#F26D5E"
}