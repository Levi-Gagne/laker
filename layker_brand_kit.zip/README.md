# Layker Brand Kit

**Generated:** 2025-08-10T19:56:30Z

## Files

- `assets/icon_primary.svg` — fish + layered lake chevrons (primary icon)
- `assets/icon_badge.svg` — circular badge variant
- `assets/icon_mono_dark.svg` — mono for dark backgrounds (white on charcoal)
- `assets/icon_mono_light.svg` — mono for light backgrounds (charcoal on white)
- `assets/wordmark_text.svg` — wordmark only
- `assets/wordmark_lockup.svg` — icon + wordmark horizontal lockup
- `color_palette.json` — canonical brand colors (hex)
  
## Colors

| Token      | Name             | Hex      | Usage                                    |
| ---------- | ---------------- | -------- | ---------------------------------------- |
| primary    | Deep Lake Blue   | #155EAD | Headings, icon fills, highlights         |
| secondary  | Aqua Teal        | #1FB9A8 | Accents, subtitles, wave elements       |
| accent     | Coral Accent     | #FF6F61 | Emphasis, CTAs                           |
| mist       | Mist             | #DCEAF5 | Background surfaces                      |
| charcoal   | Charcoal Slate   | #1B2A34 | Body text on light, mono-dark bg       |
| white      | White            | #FFFFFF | Background/light elements                |
| black      | Black            | #000000 | Utility                                  |

## Usage Guidance

- Prefer `icon_primary.svg` for product/brand contexts.  
- Use `icon_badge.svg` for avatars, favicons, or stickers.  
- Use mono variants when color is constrained.  
- Minimum icon size: 24 px. Minimum wordmark height: 28 px.
- Keep at least 1× icon radius of clear space around the mark.

## Notes

- Fonts are **system fallbacks** in SVG text (`Inter, Segoe UI, Roboto, Arial, sans-serif`).  
  If you need exact shape consistency, export outlined PNG/SVG from your design tool.
- Need PNG exports? Tell me the desired sizes (e.g., 1024/512/256/128), and I’ll add them.
